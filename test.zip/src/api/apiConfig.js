//http://dummy.restapiexample.com/api/v1/employees

const PROTOCOL = "http";
const BASE = "dummy.restapiexample.com"; //window.location.hostname;
const PORT = "80"; //location.port;

export { PROTOCOL, BASE, PORT };
